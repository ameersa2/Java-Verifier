package oop.ex6.exception;

/**
 * exception class that represents an ile=legal code line exception.
 */
public class iLLegalCodeException extends Exception{

    public iLLegalCodeException(String exception){
        super(exception);
    }
}
