package oop.ex6.main;
import oop.ex6.Parser.FileParser;
import java.io.*;

import oop.ex6.exception.iLLegalCodeException;

public class Sjavac {
    public static void main(String[] args) throws IOException {
            try {
                File file = new File(args[0]);
                FileParser.readGlobal(file);
                System.out.println(0);

            } catch (iLLegalCodeException error) {
                System.err.println(error);
                System.out.println(1);

            }

        }

}
