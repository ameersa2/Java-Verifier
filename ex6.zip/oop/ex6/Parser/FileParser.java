package oop.ex6.Parser;

import oop.ex6.checker.*;
import oop.ex6.checker.IfBlock;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import oop.ex6.checker.FinalVariableCheck;
import oop.ex6.exception.iLLegalCodeException;

public class FileParser {


    private final static String ANY_NUMBER_REGEX = "-?(?:\\d*\\.\\d+|\\d+\\.\\d*)";
    private final static String DIGIT_REGEX = "\\d+";
    private final static String STRING_REGEX = "\"+\\w+\"";
    private final static String CHAR_REGEX = "\'[a-zA-z]\'";
    private final static String OUT_OF_METHOD_SCOPE_ERROR = "if or while cannot be out of a method scope";
    private static final String STRING = "String";
    private static final String INT = "int";
    private static final String DOUBLE = "double";
    private static final String CHAR = "char";
    private static final String BOOLEAN = "boolean";
    private static final String EQUALS_SIGN = "=";
    private static final String TRUE = "true";
    private static final String FALSE = "false";
    protected final static String VALUE_NOT_MATCHING_TYPE_ERROR = "the value not matching type";
    private static final String ILLEGAL_LINE = "illegal line";
    private static final String FINAL_ERROR = "final parameter cant be changed";
    private static final String METHOD_NOT_FOUND = "method wasn't found";
    private static final String NO_SPACES_BEFORE_COMMENT_SIGN = "space white cannot be before comment line";
    private static final String NO_VALUE = "parameter has no value!";
    private static final String VOID = "void";
    private static final String IF = "if";
    private static final String WHILE = "while";
    private static final String SPACE = " ";
    private static final String FINAL = "final";




    /**
     * HashMap for if and while blocks
     */
    public static HashMap<Integer, Integer> ifWhile = new HashMap<>();

    /**
     * convert file to array
     * @param file a file to convert
     * @return an arraylist
     * @throws IOException throws.
     */
    private static ArrayList<String> FileToArray(File file) throws IOException {
        BufferedReader bufReader = new BufferedReader(new FileReader(file));
        ArrayList<String> listOfLines = new ArrayList<>();
        String line = bufReader.readLine();
        while (line != null) {
            listOfLines.add(line);
            line = bufReader.readLine();
        }
        bufReader.close();
        return listOfLines;
    }

    /**
     *  checks method parameters
     * @param stringArray parameters array
     * @param method the method name
     * @param methodNumber the method number in the file
     * @throws iLLegalCodeException throws illegal code exception
     */
    private static void checkMethodParameters(String[] stringArray, String method, int methodNumber)
            throws iLLegalCodeException {
        int parameterNum = 0;
        ArrayList<String> values = new ArrayList<>(VoidCheck.getHash().get(method).values());
        for (String parameter : stringArray) {
            parameter = parameter.trim();
            if (parameter.contains(" ")) {
                throw new iLLegalCodeException(OUT_OF_METHOD_SCOPE_ERROR);
            }

            Pattern integer = Pattern.compile(DIGIT_REGEX);
            Matcher integerMatcher = integer.matcher(parameter);
            Pattern doub = Pattern.compile(ANY_NUMBER_REGEX);
            Matcher doubMatcher = doub.matcher(parameter);
            Pattern normalString = Pattern.compile(STRING_REGEX);
            Matcher normalStringMantcher = normalString.matcher(parameter);
            Pattern normalChar = Pattern.compile(CHAR_REGEX);
            Matcher normalCharMatcher = normalChar.matcher(parameter);
            if (normalCharMatcher.matches()) {
                if (!values.get(parameterNum).equals(CHAR)) {
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                }
            } else if (normalStringMantcher.matches()) {
                if (!values.get(parameterNum).equals(STRING)) {
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                }
            } else if (doubMatcher.matches()) {
                if (!values.get(parameterNum).equals(DOUBLE)) {
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                }

            } else if (integerMatcher.matches()) {
                if (!values.get(parameterNum).equals(INT)) {
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                }
            }else if (parameter.equals(TRUE) || parameter.equals(FALSE)){
                if (!values.get(parameterNum).equals(BOOLEAN)) {
                        throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                }
            }
             else if (!VariablesCheck.globalVariables.isEmpty() && VariablesCheck.globalVariables.containsKey(parameter)) {
                if (!VariablesCheck.globalVariables.get(parameter).get(1).equals
                        (VoidCheck.methodParameterTable.get(method).get(parameter))) {
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                }
            } else {
                boolean parameterIn = false;
                int i = 0;
                while (i < VariablesCheck.localVariables.size()) {
                    if (VariablesCheck.localVariables.get(methodNumber).get(i).equals(parameter)) {
                        if (VariablesCheck.localVariables.get(methodNumber).get(i+2) != null) {
                            if (!VariablesCheck.localVariables.get(methodNumber).get(i + 2).equals
                                    (VoidCheck.methodParameterTable.get(method).get(parameter))) {
                                throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                            }
                        }
                        parameterIn = true;
                        break;
                    }
                    i += 3;
                }
                if (!parameterIn) {
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                }
            }
            parameterNum++;

        }
        if (parameterNum != VoidCheck.methodParameterTable.get(method).size()) {
            throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
        }
    }

    /**
     * prepare all data structures for reading
     */
    private static void prepareForReading(){
        VariablesCheck.localVariables = new HashMap<>();
        VariablesCheck.globalVariables = new HashMap<>();
        VoidCheck.methodParameterTable = new HashMap<>();
        VariablesCheck.suspiciousLocals = new HashMap<>();
        FinalVariableCheck.finalsArray = new ArrayList<>();
        VariablesCheck.ifWhileVariables = new HashMap<>();
        VariablesCheck.suspiciousValueAndType = new ArrayList<>();
        VariablesCheck.ValueAndType = new ArrayList<>();

    }

    /**
     * switch for multiple cases
     * @param line a line from the file
     * @param splatted array of words in a line
     * @param flag a numeric flag
     * @param insideMethod inside a method block or not
     * @param methodNumber the method number in the file
     * @param inIfWhile inside if\while block or not
     * @param IfWhileCounter the if\while number in file
     * @throws iLLegalCodeException throws illegal code exception
     */
    private static void casesSwitch(String line, String[] splatted,int flag, boolean insideMethod, int methodNumber,
                                    boolean inIfWhile, int IfWhileCounter) throws iLLegalCodeException {
        switch (splatted[flag]) {
            case INT:
                new IntegerChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                if (flag == 1) {
                    new FinalVariableCheck(line).checkLine();
                }
                break;
            case DOUBLE:
                new DoubleChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                if (flag == 1) {
                    new FinalVariableCheck(line).checkLine();
                }
                break;
            case STRING:
                new StringChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                if (flag == 1) {
                    new FinalVariableCheck(line).checkLine();
                }
                break;
            case CHAR:
                new CharChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                if (flag == 1) {
                    new FinalVariableCheck(line).checkLine();
                }
                break;
            case BOOLEAN:
                new BooleanCheck().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                if (flag == 1) {
                    new FinalVariableCheck(line).checkLine();
                }
                break;
            default:
                if (!line.startsWith("//"))
                    throw new iLLegalCodeException(ILLEGAL_LINE);

        }
    }

    /**
     * check if a method was called
     * @param insideMethod inside a method block or not
     * @param line a line from the file
     * @param methodNumber the method number in the file
     * @param methodName the name of the checked method
     * @throws iLLegalCodeException throws illegal code exception
     */
    private static void methodCallCheck(boolean insideMethod, String line, int methodNumber,
                                        String methodName) throws iLLegalCodeException {
        if (!insideMethod) {
            throw new iLLegalCodeException(OUT_OF_METHOD_SCOPE_ERROR);
        } else {
            String[] parameters = getParameters(line).split(",");
            if (!line.substring(line.indexOf("(") + 1, line.lastIndexOf(")")).isEmpty()) {
                checkMethodParameters(parameters, methodName, methodNumber);
            }
        }
    }


    /**
     * get method parameters
     * @param line a line from the file
     * @return a line of the parameters
     */
    private static String getParameters(String line){
        return line.substring(line.indexOf("(") + 1, line.lastIndexOf(")"));
    }

    /**
     * get method name
     * @param line a line from the file
     * @return the method name
     */
    private static String getMethodName(String line){
        return line.substring(0,line.indexOf("(")).trim();
    }

    /**
     * an initialization line check
     * @param line a line from the file
     * @param insideMethod inside method block or not
     * @param methodNumber the method number
     * @throws iLLegalCodeException throws illegal code exception
     */
    private static void initializationLineCheck(String line, boolean insideMethod, int methodNumber) throws iLLegalCodeException {
        String[] newLine = line.split(EQUALS_SIGN);
        newLine[0] = newLine[0].trim();
        if (FinalVariableCheck.getArray().contains(newLine[0].trim())) {
            throw new iLLegalCodeException(FINAL_ERROR);
        }
        if (!insideMethod) {

            if (VariablesCheck.globalVariables.containsKey(newLine[0])) {
                String type = VariablesCheck.globalVariables.get(newLine[0].trim()).get(1);
                ArrayList<String> arrayList = new ArrayList<>();
                arrayList.add(newLine[1].trim());
                arrayList.add(type);
                VariablesCheck.globalVariables.put(newLine[0].trim(), arrayList);
            } else {
                throw new iLLegalCodeException(ILLEGAL_LINE);
            }
        } else {
            if (methodNumber <= VariablesCheck.localVariables.size()) {
                if (VariablesCheck.localVariables.get(methodNumber).contains(newLine[0].trim())) {

                    String type = VariablesCheck.localVariables.get(methodNumber).get(2);
                    ArrayList<String> arrayList = new ArrayList<>();
                    arrayList.add(newLine[0].trim());
                    arrayList.add(newLine[1].trim());
                    arrayList.add(type);
                    VariablesCheck.localVariables.put(methodNumber, arrayList);
                }
            } else {
                throw new iLLegalCodeException(ILLEGAL_LINE);
            }
        }
    }

    /**
     * checks local variables
     * @param allMethods methods array
     * @throws iLLegalCodeException throws illegal code exception
     */
    private static void localVariablesCheck(String[] allMethods) throws iLLegalCodeException {
        for (int methodNum : VariablesCheck.suspiciousLocals.keySet()) {
            if (VoidCheck.methodParameterTable.size() != 0) {
                if (VoidCheck.methodParameterTable.get(allMethods[methodNum]).
                        containsKey(VariablesCheck.suspiciousLocals.get(methodNum).get(0)))
                    continue;
            }
            if (!VariablesCheck.globalVariables.isEmpty()) {
                if (!checkLocals(methodNum) && !checkGlobals(methodNum)) {
                    throw new iLLegalCodeException(ILLEGAL_LINE);
                }
            }

            else if (!VariablesCheck.ValueValidity(VariablesCheck.suspiciousLocals.get(methodNum).get(1),
                    VariablesCheck.suspiciousLocals.get(methodNum).get(0))) {
                throw new iLLegalCodeException(ILLEGAL_LINE);
            }
        }
    }

    /**
     * checks suspicious methods
     * @param suspiciousMethods hash map of suspicious methods
     * @param methodNumber the method number to check
     * @throws iLLegalCodeException throws illegal code exception
     */
    private static void suspiciousMethodsCheck(HashMap<String, ArrayList<String>> suspiciousMethods, int methodNumber)
            throws iLLegalCodeException {
        for (String method : suspiciousMethods.keySet()){
            if (VoidCheck.getHash().containsKey(method)){
                String[] arr = suspiciousMethods.get(method).toArray(new String[0]);
                checkMethodParameters(arr,method, methodNumber);
            }else {
                throw new iLLegalCodeException(METHOD_NOT_FOUND);
            }
        }
    }

    /**
     * read the file line by line
     * @param file a file to read
     * @throws iLLegalCodeException throws illegal code exception
     * @throws IOException throws IO exception
     */
    public static void readGlobal(File file) throws iLLegalCodeException, IOException {
        ArrayList<String> Lines = FileToArray(file);
        HashMap<String,ArrayList<String>> suspiciousMethods = new HashMap<>();
        prepareForReading();

        String[] allMethods = new String[3];

        boolean parathenesses = false;
        boolean insideMethod = false;
        int methodNumber = 0;
        boolean inIfWhile = false;
        int parenthesesCounter = 0;
        int IfWhileCounter = 0;
        int AllParenthesesCounter = 0;
        for (String line : Lines) {
            if (line.trim().startsWith("//") && line.startsWith(" ")) {
                throw new iLLegalCodeException(NO_SPACES_BEFORE_COMMENT_SIGN);
            }
            if (line.startsWith("//")){
                continue;
            }
            if (line.isEmpty())
                continue;
            line = line.trim();

            if (line.endsWith("{")) {
                AllParenthesesCounter++;
            }
            if (line.equals("}")) {
                AllParenthesesCounter--;
            }


            if (line.equals("return;") ||
                    (line.split(SPACE)[0].equals("return") &&
                            line.split(SPACE)[line.split(SPACE).length - 1].equals(";"))) {
                insideMethod = false;
                parathenesses = true;
                continue;

            }
            if (parathenesses) {
                if (line.trim().equals("}")) {
                    parathenesses = false;
                    continue;
                }
                throw new iLLegalCodeException("} is missing");
            }
            String[] splatted = line.split(SPACE);
            int j = 0;
            if (parenthesesCounter == 1) {
                j++;
            }

            if (splatted[0].equals(IF) || splatted[0].equals(WHILE)) {
                inIfWhile = true;
                if (splatted[splatted.length - 1].endsWith("{")) {
                    parenthesesCounter++;
                }
                if (splatted[splatted.length - 1].endsWith("}")) {
                    ifWhile.put(j, parenthesesCounter);
                    parenthesesCounter--;
                }
            }
            if (parenthesesCounter == 0) {
                inIfWhile = false;
            }


            if (splatted[0].equals(VOID)) {

                methodNumber += 1;
                String methodName = "";
                if (line.contains("(")) {
                    methodName = line.substring(line.indexOf("d") + 1, line.indexOf("(")).trim();
                    allMethods[methodNumber] = methodName;
                }
                if (insideMethod) {
                    throw new iLLegalCodeException(ILLEGAL_LINE);
                }
                insideMethod = true;
                new VoidCheck().lineCheck(line, methodNumber);
            }

            int flag = 0;
            if (splatted[0].equals(FINAL)) {
                flag = 1;
            }
            if (flag == 1) {
                line = line.substring(line.indexOf("l") + 1);
            }

            String ifWhileName = "";
            if (line.startsWith(IF) || line.startsWith(WHILE)){
                ifWhileName = getMethodName(line);
            }

            if (splatted[0].equals(IF) || splatted[0].equals(WHILE) || ifWhileName.equals(WHILE) ||
                    ifWhileName.equals(IF)) {
                IfWhileCounter++;
                if (!insideMethod) {
                    throw new iLLegalCodeException(OUT_OF_METHOD_SCOPE_ERROR);
                } else {
                    new IfBlock(line, VariablesCheck.globalVariables, VariablesCheck.localVariables,
                            VoidCheck.methodParameterTable).checkValidity(methodNumber);
                    continue;
                }
            }
            Pattern p = Pattern.compile(",");
            Matcher m = p.matcher(line);
            Pattern p1 = Pattern.compile("\\(");
            Matcher m1 = p1.matcher(line);
            if (m.find() && !m1.find()) {
                String[] s = line.split(",");
                String[] lines = new String[s.length];
                lines[0] = (s[0] + ";").trim();
                lines[s.length - 1] = (splatted[flag] + SPACE + s[s.length - 1]).trim();
                for (int i = 0; i < s.length; i++) {
                    if (i != 0 && i != s.length - 1)
                        lines[i] = splatted[flag] + s[i] + ";";
                    casesSwitch(lines[i], splatted, flag, insideMethod,methodNumber, inIfWhile, IfWhileCounter);
                }

            } else {
                switch (splatted[flag]) {
                    case INT:
                        new IntegerChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                        if (flag == 1) {
                            new FinalVariableCheck(line).checkLine();
                        }
                        break;
                    case DOUBLE:
                        new DoubleChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                        if (flag == 1) {
                            new FinalVariableCheck(line).checkLine();
                        }
                        break;
                    case STRING:
                        new StringChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                        if (flag == 1) {
                            new FinalVariableCheck(line).checkLine();
                        }
                        break;
                    case CHAR:
                        new CharChecker().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                        if (flag == 1) {
                            new FinalVariableCheck(line).checkLine();
                        }
                        break;
                    case BOOLEAN:
                        new BooleanCheck().lineCheckLegality(line, insideMethod, methodNumber, inIfWhile, IfWhileCounter);
                        if (flag == 1) {
                            new FinalVariableCheck(line).checkLine();
                        }
                        break;
                    case "}":
                    case "return;":
                    case VOID:
                        continue;
                    default:
                        String methodName = "";
                        if (line.contains("(")) {
                            methodName = getMethodName(line);
                        }
                        Pattern function = Pattern.compile("\\s*[A-Za-z]\\w* *\\(.*\\) *;\\s*");
                        Matcher matcher = function.matcher(line.trim());
                        if (VoidCheck.methodParameterTable.containsKey(methodName)) {
                            methodCallCheck(insideMethod,line,methodNumber,methodName);
                        } else if (line.contains("=")) {
                            initializationLineCheck(line,insideMethod, methodNumber);

                        }else if (matcher.matches()){
                            if (!insideMethod){
                                throw new iLLegalCodeException(OUT_OF_METHOD_SCOPE_ERROR);
                            }
                            String[] parameters = line.substring
                                    (line.indexOf("(") + 1, line.lastIndexOf(")")).split(",");
                            suspiciousMethods.put(methodName,new ArrayList<>(Arrays.asList(parameters)));
                        }
                        else {
                            throw new iLLegalCodeException(ILLEGAL_LINE);
                        }
                        break;
                }
            }

        }

        if (insideMethod || parathenesses) {
            throw new iLLegalCodeException(ILLEGAL_LINE);
        }
        if (AllParenthesesCounter != 0) {
            throw new iLLegalCodeException(ILLEGAL_LINE);
        }
        localVariablesCheck(allMethods);
        suspiciousMethodsCheck(suspiciousMethods,methodNumber);
    }

    /**
     * check local variables
     * @param methodNum the method number
     * @return true if was found
     * @throws iLLegalCodeException throws illegal code exception
     */
    private static boolean checkLocals(int methodNum) throws iLLegalCodeException {

        boolean flag = false;
        int i = 0;
        if (VariablesCheck.localVariables != null && VariablesCheck.suspiciousLocals != null) {
            while (i < VariablesCheck.localVariables.size()) {
                if (VariablesCheck.localVariables.get(methodNum).get(i).equals(VariablesCheck.suspiciousLocals.
                        get(methodNum).get(0))) {
                    flag = true;
                    break;
                }
                i += 3;
            }
            if (flag && VariablesCheck.localVariables.get(methodNum).get(i).equals("")) {
                throw new iLLegalCodeException(NO_VALUE);
            }
        }
        return flag;
    }

    /**
     * check global variables
     * @param methodNum the method number
     * @return true if ws found
     */
    private static boolean checkGlobals(int methodNum) {
        String val = VariablesCheck.suspiciousLocals.get(methodNum).get(0);
        return VariablesCheck.globalVariables.containsKey(val) &&
                (!VariablesCheck.globalVariables.get(val).get(0).equals(""));
    }

}
