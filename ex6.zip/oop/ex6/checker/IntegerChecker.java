package oop.ex6.checker;

import oop.ex6.exception.iLLegalCodeException;

import java.util.PrimitiveIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IntegerChecker extends VariablesCheck {

    private final static String INT = "int";
    private final static String numRegex =  "-?(?:\\d+)";

    @Override
    public void lineCheckLegality(String line, boolean insideMethod, int methodNumber, boolean insideIfWhile,
                                  int IfWhileNumber) throws iLLegalCodeException {
        checkBasics(line);
        String name = getName(line, "t");
        if (NameCheck(name)) {
            throw new iLLegalCodeException(NAME_PARAMETER_ERROR);
        }
        String value = getValue(line);
        if (value.contains("(")) {
            throw new iLLegalCodeException(NOT_VALID_VALUE);
        }
        if (initializationCheck(line)) {
            if (!isInteger(value)) {
                if (insideMethod) {
                    if (!insideIfWhile) {
                        if (!isBoolean(value)) {
                            throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                        }
                        updateSuspicious(methodNumber, value, suspiciousLocals, INT);
                    }
                } else {
                    if (globalVariables.size() != 0) {
                        if (globalVariables.get(value).get(0).equals(""))
                            throw new iLLegalCodeException(NO_VALUE_ERROR);
                        if (!globalVariables.containsKey(value)) {
                            throw new iLLegalCodeException(ERROR_IN_GLOBAL_VAR);
                        } else {
                            boolean flag = false;
                            if (globalVariables.containsKey(value)) {
                                value = globalVariables.get(value).get(0);
                                flag = true;
                            }
                            if (!flag) {
                                Pattern integer = Pattern.compile(numRegex);
                                Matcher integerMatcher = integer.matcher(globalVariables.get(value).get(0));
                                if (!integerMatcher.matches())
                                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                            }

                        }
                    }
                }
            }
        }
        updateVariables(insideMethod, insideIfWhile, IfWhileNumber, methodNumber, name, value, INT);
        if (!insideMethod) {
            if (!value.equals("")) {
                Pattern integer = Pattern.compile(numRegex);
                Matcher integerMatcher = integer.matcher(value);
                if (!integerMatcher.matches())
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
            }
            updateGlobalHashMap(name, value, INT);
        }

    }
}