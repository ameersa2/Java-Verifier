package oop.ex6.checker;

import oop.ex6.exception.iLLegalCodeException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * the class of the if block class
 */
public class IfBlock {
    protected String string;
    protected HashMap<String, ArrayList<String>> globalVariables;
    protected HashMap<Integer, ArrayList<String>> localVariables;
    protected HashMap<String, HashMap<String, String>> methodsParameters;
    protected static final String AND_OR_REGEX = "&{2}|\\|{2}";
    protected static final String DOUBLE_OR_INT_REGEX = "-?(?:\\d+|\\d*\\.\\d+|\\d+\\.\\d*)";
    protected static final String SPACE = " ";
    protected static final String EXCEPTION_PRINT_MSG = "the condiotions can be a method call or boolean or " +
            "Double or integer";
    protected static final String EMPTY = "";
    protected static final int ZERO = 0;
    protected static final String OPEN_BRACKETS = "(";
    protected static final String CLOSE_BRACKETS = ")";
    protected static final String TRUE = "true";
    protected static final String FALSE = "false";
    protected static final String INT = "int";
    protected static final String DOUBLE = "double";
    protected static final String BOOLEAN = "boolean";


    /**
     * the constructor of the (if or while) filrst line check
     *
     * @param string            the line if ythwe first line of the if or while block
     * @param globalVariables   globalVariables
     * @param localVariables    localVariables
     * @param methodsParameters methodsParameters
     */
    public IfBlock(String string, HashMap<String, ArrayList<String>> globalVariables, HashMap<Integer,
            ArrayList<String>> localVariables, HashMap<String, HashMap<String, String>> methodsParameters) {
        this.string = string;
        this.globalVariables = globalVariables;
        this.localVariables = localVariables;
        this.methodsParameters = methodsParameters;
    }


    /**
     * With this method we will check if the first line of the if or while block and check if the condition is legal or
     * not, so in general we are checking if the shape is wright is legal and if the conditions are too.
     * if the the condition is an method call we will use the checkMethodPrameters method , otherwise we will use
     * checkIfCondition method.
     *
     * @param methodNumber the number of the method.
     * @throws iLLegalCodeException if or while cannot be out of a method scope
     */
    public void checkValidity(int methodNumber) throws iLLegalCodeException {
        String string1 = this.string.trim();
        if (!string1.endsWith("{")) {
            throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
        }
        int firstIndex = string1.indexOf(OPEN_BRACKETS) + 1;
        int lastInd = string1.lastIndexOf(CLOSE_BRACKETS);
        String allConditions = string1.substring(firstIndex, lastInd);
        Pattern splittingAndOr = Pattern.compile(AND_OR_REGEX);
        Matcher splittingAndOrMatcher = splittingAndOr.matcher(allConditions);
        String[] conditions;
        if (splittingAndOrMatcher.find())
            conditions = allConditions.split(AND_OR_REGEX);
        else {
            allConditions = allConditions.trim();
            if (allConditions.trim().split(SPACE).length != 1) {
                throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
            }
            conditions = allConditions.split(SPACE);
        }
        for (String cond : conditions) {
            cond = cond.trim();
            if (cond.equals(EMPTY))
                throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
            Pattern pattern = Pattern.compile("\\w+");
            Matcher matcher = pattern.matcher(cond);
            if (!matcher.matches()) {
                throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
            }
            String method = EMPTY;
            if (cond.contains(OPEN_BRACKETS))
                method = cond.substring(ZERO, cond.indexOf(OPEN_BRACKETS) + 1);
            if (this.methodsParameters.containsKey(method)) {
                String[] parameters = cond.substring(cond.indexOf(OPEN_BRACKETS) + 1,
                        cond.lastIndexOf(CLOSE_BRACKETS)).split(",");
                if (!checkMethodPrameters(parameters, method, methodNumber)) {
                    throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
                }
            } else if (!checkIfCondition(cond, methodNumber)) {
                throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
            }
        }

    }


    /**
     * In this method we will check if the parameters of the method fits the type that the method can recieve and checking
     * if the number of the parameters also fits the method parameters number
     *
     * @param stringArray  the conditions
     * @param method       methods name
     * @param methodNumber methods Number
     * @return true or false
     * @throws iLLegalCodeException print msg
     */
    private boolean checkMethodPrameters(String[] stringArray, String method, int methodNumber) throws iLLegalCodeException {
        int parameterNum = 0;
        for (String parameter : stringArray) {
            parameter = parameter.trim();
            if (!parameter.contains(SPACE)) {
                throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
            }
            if (this.globalVariables.containsKey(parameter)) {
                if (!this.globalVariables.get(parameter).get(1).equals(
                        this.methodsParameters.get(method).get(parameter))) {
                    throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
                }
            } else {
                boolean parameterIn = false;
                int i = 0;
                while (i < this.localVariables.size()) {
                    if (this.localVariables.get(methodNumber).get(i).equals(parameter)) {
                        if (!this.localVariables.get(methodNumber).get(i + 2).equals(
                                this.methodsParameters.get(method).get(parameter))) {
                            throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
                        }
                        parameterIn = true;
                        break;
                    }
                    i += 3;
                }
                if (!parameterIn) {
                    throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
                }
            }
            parameterNum++;
        }
        if (parameterNum + 1 != this.methodsParameters.get(method).size()) {
            throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
        }
        return true;
    }


    /**
     * in this method we will check if the (if or while) condiotions is not method call
     *
     * @param str          condition
     * @param methodNumber methods Number
     * @return true or false
     * @throws iLLegalCodeException print msg
     */
    private boolean checkIfCondition(String str, int methodNumber) throws iLLegalCodeException {
        if ((str.equals(TRUE) || str.equals(FALSE)))
            return true;
        Pattern p = Pattern.compile(DOUBLE_OR_INT_REGEX);
        Matcher m = p.matcher(str);
        if (m.matches()) {
            return true;
        }
        Pattern pattern = Pattern.compile("\\w+");
        Matcher matcher = pattern.matcher(str);
        if (!matcher.matches()) {
            throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
        }
        String type = EMPTY;
        int i = 0;
        if (this.globalVariables.containsKey(str)) {
            type = this.globalVariables.get(str).get(1);

        } else {

            while (i < this.localVariables.get(methodNumber).size()) {
                if (this.localVariables.get(methodNumber).get(i).equals(str)) {
                    type = this.localVariables.get(methodNumber).get(i + 2);
                    break;
                }
                i += 3;
            }
        }
        if (this.localVariables.get(methodNumber).get(i + 1).isEmpty()) {
            return false;
        }
        if (type.equals(INT) || type.equals(DOUBLE) || type.equals(BOOLEAN)) {
            return true;
        }

        throw new iLLegalCodeException(EXCEPTION_PRINT_MSG);
    }
}
