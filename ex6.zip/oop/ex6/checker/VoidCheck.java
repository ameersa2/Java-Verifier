package oop.ex6.checker;

import oop.ex6.exception.iLLegalCodeException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoidCheck {

    private static final String REGEX = "[A-Za-z]\\w* *";
    private static final String SPACE = " ";
    private static final String BRACKETS_MISSING = "{ is missing";
    private static final String END_LINE_ERROR = "Error in the end of method line";
    private static final String NOT_VALID_METHOD_NAME = "method name is illegal";
    private static final String REGEX_BRACKETS = "[\\(\\)]";
    private static final String CIRCLE_BRACKETS_MISSING = "( or ) is missing";
    private static final String PARAMETER_NAME_ERROR = "illegal parameter name";
    private static final String FINAL = "final";
    private static final String STRING = "String";
    private static final String INT = "int";
    private static final String DOUBLE = "double";
    private static final String CHAR = "char";
    private static final String BOOLEAN = "boolean";
    private static final String METHOD_PARAMETER_ERROR = "ERROR in method parameter";

    /** a hashmap for method variables*/
    public static HashMap<String, HashMap<String, String>> methodParameterTable = new HashMap<>();

    /**
     * @return the method hash map
     */
    public static HashMap<String, HashMap<String, String>> getHash() {
        return methodParameterTable;
    }

    /**
     * checks method name legality
     * @param name a method name to check
     * @return true if the name is legal, false otherwise.
     */
    private boolean NameCheck(String name) {

        Pattern pattern = Pattern.compile(REGEX);
        Matcher m = pattern.matcher(name);
        if (name.length() == 0) {
            return true;
        }
        if (name.trim().contains(SPACE)) {
            return true;
        } else {
            return !m.matches();
        }

    }

    /**
     * checks method lines legality.
     * @param line a line from method block
     * @param methodNumber the number of the method in the file
     * @throws iLLegalCodeException throws illegal code exception.
     */
    public void lineCheck(String line, int methodNumber) throws iLLegalCodeException {
        line = line.trim();
        if (!line.endsWith("{")) {
            throw new iLLegalCodeException(BRACKETS_MISSING);
        }
        if (!line.substring(line.indexOf(")") + 1, line.indexOf("{")).isBlank()) {
            throw new iLLegalCodeException(END_LINE_ERROR);
        }
        String nameSubString = line.substring(4, line.indexOf("(")).trim();

        if (NameCheck(nameSubString)) {
            throw new iLLegalCodeException(NOT_VALID_METHOD_NAME);
        }
        Pattern pattern = Pattern.compile(REGEX_BRACKETS);
        Matcher matcher = pattern.matcher(line);
        if (!matcher.find()) {
            throw new iLLegalCodeException(CIRCLE_BRACKETS_MISSING);
        }
        String methodParameters = line.substring(line.indexOf("(") + 1, line.indexOf(")"));
        methodParameters = methodParameters.trim();
        methodParameterTable.put(nameSubString, new HashMap<>());
        VariablesCheck.localVariables.put(methodNumber, new ArrayList<>());
        if (!methodParameters.isBlank()) {
            String[] parametersArray = methodParameters.split(",");
            HashMap<String, String> parameterId = new HashMap<>();
            ArrayList<String> valueType = new ArrayList<>();
            for (String parameter : parametersArray) {
                parameter = parameter.trim();
                if (parameter.replaceAll("\\s+", SPACE).split(SPACE).length!= 2){
                    throw new iLLegalCodeException(PARAMETER_NAME_ERROR);
                }
                String[] NameAndType = parameter.split(SPACE);
                if (NameAndType[0].equals(FINAL))
                    throw new iLLegalCodeException(PARAMETER_NAME_ERROR);
                String[] realNameAndType = new String[2];
                realNameAndType[0] = NameAndType[0].trim();
                realNameAndType[1] = NameAndType[NameAndType.length - 1].trim();

                if (parameterId.containsKey(realNameAndType[1].trim())) {
                    throw new iLLegalCodeException(PARAMETER_NAME_ERROR);
                }
                if (!VariablesCheck.NameCheck(realNameAndType[1].trim())) {
                    if (realNameAndType[0].equals(INT) || realNameAndType[0].equals(DOUBLE) ||
                            realNameAndType[0].equals(STRING) || realNameAndType[0].equals(CHAR)
                            || realNameAndType[0].equals(BOOLEAN)) {
                        valueType.add(realNameAndType[1]);
                        valueType.add(realNameAndType[0]);
                        valueType.add(null);
                        parameterId.put(realNameAndType[1].trim(), realNameAndType[0]);
                    }
                    else {
                        throw new iLLegalCodeException(METHOD_PARAMETER_ERROR);
                    }
                } else
                    throw new iLLegalCodeException(METHOD_PARAMETER_ERROR);
            }
            methodParameterTable.put(nameSubString, parameterId);
            VariablesCheck.localVariables.put(methodNumber, valueType);
        }


    }

}
