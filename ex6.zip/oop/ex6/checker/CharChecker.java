package oop.ex6.checker;

import oop.ex6.exception.iLLegalCodeException;

public class CharChecker extends VariablesCheck{


    protected final static String CHAR = "char";


    @Override
    public void lineCheckLegality(String line,boolean insideMethod, int methodNumber,boolean insideIfWhile,
                                  int IfWhileNumber) throws iLLegalCodeException {
        checkBasics(line);
        String name = getName(line, "r");
        if (NameCheck(name)) {
            throw new iLLegalCodeException(NAME_PARAMETER_ERROR);
        }
        String value = getValue(line);
        if (value.contains("(")) {
            throw new iLLegalCodeException(NOT_VALID_VALUE);
        }
        if (initializationCheck(line)) {
            if (!isChar(value)) {
                if (insideMethod) {
                    if (!insideIfWhile) {
                        if (!isBoolean(value) || isDouble(value) || isInteger(value)) {
                            throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                        }
                        updateSuspicious(methodNumber, value, suspiciousLocals, CHAR);
                    }
                } else {
                    if (globalVariables.size() != 0) {
                        if (globalVariables.get(value).get(0).equals(""))
                            throw new iLLegalCodeException(NOT_VALID_VALUE);
                        if (!globalVariables.containsKey(value)) {
                            throw new iLLegalCodeException(ERROR_IN_GLOBAL_VAR);
                        }
                        else {
                            boolean flag = false;
                            if (globalVariables.containsKey(value)) {
                                value = globalVariables.get(value).get(0);
                                flag = true;
                            }
                            if (!flag){
                                if (!isChar(globalVariables.get(value).get(0)))
                                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
                            }

                        }
                    }
                }
            }
        }
        updateVariables(insideMethod,insideIfWhile,IfWhileNumber,methodNumber,name,value, CHAR);
        if (!insideMethod) {
            if (!value.equals("")) {
                if (!isChar(value))
                    throw new iLLegalCodeException(VALUE_NOT_MATCHING_TYPE_ERROR);
            }
            updateGlobalHashMap(name, value, CHAR);
        }
    }
}
