package oop.ex6.checker;

import oop.ex6.exception.iLLegalCodeException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class VariablesCheck {

    public static ArrayList<String> suspiciousValueAndType = new ArrayList<>();
    public static ArrayList<String> ValueAndType = new ArrayList<>();
    public static HashMap<Integer,ArrayList<String>> suspiciousLocals = new HashMap<>();
    public static HashMap<String , ArrayList<String>> globalVariables = new HashMap<>();
    public static HashMap<Integer , ArrayList<String>> localVariables = new HashMap<>();
    public static HashMap<Integer,ArrayList<String>> ifWhileVariables = new HashMap<>();


    protected final static String NAME_PARAMETER_ERROR = "parameter name is illegal";
    protected final static String VALUE_NOT_MATCHING_TYPE_ERROR = "the value not matching type";
    protected final static String NO_VALUE_ERROR = "there is no value for parameter";
    protected final static String ERROR_IN_GLOBAL_VAR = "global variable cannot be used before initialization";
    protected final static String NOT_VALID_VALUE = "parameter name is illegal";
    protected final static String NOT_VALID_PARAMETER = "NOT_VALID_PARAMETER";
    protected final static String TOO_MUCH_SPACES = "too much spaces in the line";
    private static final String STRING = "String";
    private static final String INT = "int";
    private static final String DOUBLE = "double";
    private static final String CHAR = "char";
    private static final String BOOLEAN = "boolean";
    private static final String EQUALS_SIGN = "=";
    private static final String TRUE = "true";
    private static final String FALSE = "false";
    private static final String NAME_REGEX = "([A-Za-z]|_\\w)+\\w*";
    private static final String ALL_REGEX = "\".*\"";
    private static final String EMPTY = "";
    private static final String SPACE = " ";
    private static final String ILLEGAL_LINE = "illegal line";
    private static final String MISSING_END = "; is missing";

    /**
     * updates Global HashMap
     * @param name variable name
     * @param value variable value
     * @param type variable type
     */
    protected void updateGlobalHashMap(String name, String value, String type){
        ArrayList<String> ValueAndType = new ArrayList<>();
        ValueAndType.add(value);
        ValueAndType.add(type);
        globalVariables.put(name, ValueAndType);
    }

    /**
     * return local variables
     * @return local variables hash map
     */
    public static HashMap<Integer, ArrayList<String>> getHashMapLocal(){
        return localVariables;
    }

    /**
     * updates Local HashMap
     * @param methodNum the method number
     * @param name variable name
     * @param value variable value
     * @param type variable type
     * @throws iLLegalCodeException throw illegal code exception
     */
    protected void updateLocalHashMap(int methodNum, String name, String value, String type) throws iLLegalCodeException {
        updateHashMap(getHashMapLocal(),methodNum,name,value,type);
    }

    /**
     *
     * @param methodNumber the method number
     * @param value the variable value
     * @param hashMap a hash map of the value and tpe
     */
    protected void updateSuspicious(int methodNumber,String value,HashMap<Integer,ArrayList<String>> hashMap, String type){
        suspiciousValueAndType.add(value);
        suspiciousValueAndType.add(type);
        hashMap.put(methodNumber, suspiciousValueAndType);
    }

    /**
     * update hash map
     * @param hashTable the hash map to update
     * @param methodNum the method number
     * @param name the variable name
     * @param value the variable value
     * @param type the variable type
     * @throws iLLegalCodeException throws illegal code exception
     */
    protected void updateHashMap(HashMap<Integer, ArrayList<String>> hashTable,int methodNum, String name, String value,
                                 String type) throws iLLegalCodeException {
        ValueAndType.add(name);
        ValueAndType.add(value);
        ValueAndType.add(type);
        hashTable.put(methodNum, ValueAndType);
    }

    /**
     *
     * @param IfNum the if\ while number in the file
     * @param name the variable name
     * @param value the variable value
     * @param type the variable type
     */
    protected void updateIfHashMap(int IfNum, String name, String value, String type){
        ValueAndType.add(name);
        ValueAndType.add(value);
        ValueAndType.add(type);
        ifWhileVariables.put(IfNum, ValueAndType);
    }

    /**
     * an abstract method that checks a specific line
     * @param line the line to check
     * @param insideMethod inside method block or not
     * @param methodNumber the method number
     * @param insideIfWhile inside if while block or not
     * @param IfWhileNumber if\ while number
     * @throws iLLegalCodeException throws illegal code exception
     */
    public abstract void lineCheckLegality(String line,boolean insideMethod, int methodNumber,
                                           boolean insideIfWhile, int IfWhileNumber) throws iLLegalCodeException;

    /**
     * checks if the value is a double
     * @param str a str to check
     * @return true if it is double
     */
    public static boolean isDouble(String str) {
        try {
            Double.parseDouble(str.trim());
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        return true;
    }

    /**
     * check name validity
     * @param name a name to check
     * @return true if the name is legal
     */
    public static boolean NameCheck(String name){
        Pattern pattern = Pattern.compile(NAME_REGEX);
        Matcher matcher = pattern.matcher(name);
        if (name.length() == 0){
            return true;
        }
        if (name.trim().contains(SPACE)){
            return true;
        }
        else return !matcher.matches();
    }

    /**
     * checks if the line ends with ";"
     * @param line a line to check
     * @return true if was found
     */
    protected boolean EndsWithSimiColumnCheck(String line) {
        String[] splitLine = line.split(SPACE);
        if (splitLine[splitLine.length - 1].contains(";")) {
            return (splitLine[splitLine.length - 1].split(EMPTY)
                    [splitLine[splitLine.length - 1].split(EMPTY).length - 1].equals(";"));
        }
        return false;
    }

    /**
     * checks if the line contains '='
     * @param line a line to check
     * @return true if was found
     */
    protected boolean initializationCheck(String line){
        return line.contains(EQUALS_SIGN);
    }

    /**
     * checks if there is no needed spaces
     * @param line a  line to check
     * @return false if was found
     */
    protected boolean noSpaces(String line){
        if (initializationCheck(line)){
            return line.contains(EQUALS_SIGN);
        }
        return line.endsWith(";");
    }
    /**
     * checks if the value is a string
     * @param str a str to check
     * @return true if it is string
     */
    protected static boolean isString(String str){
        return str.matches(ALL_REGEX);
    }
    /**
     * checks if the value is a char
     * @param str a str to check
     * @return true if it is char
     */
    protected static boolean isChar(String str){
        return str.matches("'.'");
    }
    /**
     * checks if the value is a integer
     * @param str a str to check
     * @return true if it is integer
     */
    protected static boolean isInteger(String str) {
        try {
            Integer.parseInt(str);
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        return true;
    }
    /**
     * checks if the value is a boolean
     * @param value a str to check
     * @return true if it is boolean
     */
    protected static boolean isBoolean(String value){
        return ((!value.equals(TRUE)) &&
                (!value.equals(FALSE)) &&
                (!isDouble(value)));
    }

    /**
     * checks if the value matches the type
     * @param type variable type
     * @param value variable value
     * @return true if matches
     */
    public static boolean ValueValidity(String type , String value){
        switch (type){
            case INT:
                return isInteger(value);
            case BOOLEAN:
                return isBoolean(value);
            case DOUBLE:
                return isDouble(value);
            case STRING:
                return isString(value);
            case CHAR:
                return isChar(value);
        }
        return false;
    }

    /**
     * gets the variable name
     * @param line a line
     * @param letter the type last letter
     * @return the name
     */
    protected String getName(String line, String letter){
        String name;
        if (initializationCheck(line)) {

            name = (line.substring(line.indexOf(letter) + 1, line.indexOf(EQUALS_SIGN)).trim());
        } else {
            name = line.substring(line.indexOf(letter) + 1, line.indexOf(";")).trim();
        }
        return name;
    }

    /**
     * gets the variable value
     * @param line a line from the file
     * @return the value
     */
    protected String getValue(String line){
        String value = EMPTY;
        if (initializationCheck(line)) {
            String[] splitLine = line.split(EQUALS_SIGN);
            value = splitLine[splitLine.length - 1].substring(0, splitLine[splitLine.length - 1].length() - 1).trim();
        }
        return value;
    }

    /**
     * checks if the line is basically legal
     * @param line a line to check
     * @throws iLLegalCodeException throw illegal code exception
     */
    protected void checkBasics(String line) throws iLLegalCodeException {
        if (line.trim().endsWith("{"))
            throw new iLLegalCodeException(ILLEGAL_LINE);

        if (line.split(SPACE).length <= 1) {
            throw new iLLegalCodeException(NAME_PARAMETER_ERROR);
        }
        if (!EndsWithSimiColumnCheck(line)) {
            throw new iLLegalCodeException(MISSING_END);
        }
        if (!noSpaces(line)) {
            throw new iLLegalCodeException(TOO_MUCH_SPACES);
        }
    }

    /**
     * updates variables
     * @param insideMethod inside method or not
     * @param insideIfWhile inside if\while or not
     * @param IfWhileNumber if\while number
     * @param methodNumber method number
     * @param name variable name
     * @param value variable value
     * @param type variable type
     * @throws iLLegalCodeException throws illegal code exception
     */
    protected void updateVariables(boolean insideMethod, boolean insideIfWhile, int IfWhileNumber , int methodNumber,
                                   String name, String value,String type) throws iLLegalCodeException {
        if (insideMethod) {
            if (insideIfWhile) {
                updateIfHashMap(IfWhileNumber, name, value, type);
            }

            if (localVariables.get(methodNumber).size() != 0 && localVariables.get(methodNumber).get(0).equals(name)
                    &&!insideIfWhile) {
                throw new iLLegalCodeException(NOT_VALID_PARAMETER);
            }
            updateLocalHashMap(methodNumber, name, value, type);
        }
    }
}
