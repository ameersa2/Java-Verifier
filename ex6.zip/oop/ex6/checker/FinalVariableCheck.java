package oop.ex6.checker;

import oop.ex6.exception.iLLegalCodeException;

import java.util.ArrayList;

public class FinalVariableCheck {

    private static final String EQUALS_SIGN = "=";
    private static final String EMPTY = "";
    private static final String SPACE = " ";
    private static final String FINAL_INVALID = "error final line should contain =";


    protected String finalLine;
    public static ArrayList<String> finalsArray = new ArrayList<>();
    public static ArrayList<String> getArray(){
        return finalsArray;
    }
    public FinalVariableCheck(String finalLine){
        this.finalLine = finalLine;
    }

    public ArrayList<String> getFinalsArray(){
        return finalsArray;
    }


    public void checkLine() throws iLLegalCodeException {
        if (!this.finalLine.contains(EQUALS_SIGN)){
            throw new iLLegalCodeException(FINAL_INVALID);
        }
        this.finalLine = this.finalLine.trim();
        finalsArray.add(this.finalLine.split(SPACE)[1].replaceAll(SPACE, EMPTY).split(EQUALS_SIGN)[0]);
    }
}
